Hello World in jsFiddle
http://jsfiddle.net/johnpapa/BEzJc/ 

MVVM in jsFiddle - object literal
http://jsfiddle.net/johnpapa/u9S93/ 

MVVM in jsFiddle - Function
http://jsfiddle.net/johnpapa/zBqxy/ 
